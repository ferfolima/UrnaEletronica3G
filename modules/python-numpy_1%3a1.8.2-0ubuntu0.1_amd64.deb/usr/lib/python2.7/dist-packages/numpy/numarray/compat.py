from __future__ import division, absolute_import, print_function

__all__ = ['NewAxis', 'ArrayType']

from numpy import newaxis as NewAxis, ndarray as ArrayType
