"""The IPython HTML Notebook"""

import os
# Packagers: modify this line if you store the notebook static files elsewhere
DEFAULT_STATIC_FILES_PATH = "/usr/share/ipython/notebook/static"

del os
