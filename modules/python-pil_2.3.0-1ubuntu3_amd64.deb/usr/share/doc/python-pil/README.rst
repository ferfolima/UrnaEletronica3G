Pillow
======

*Python Imaging Library (Fork)*

Pillow is the "friendly" PIL fork by Alex Clark and Contributors. PIL is the Python Imaging Library by Fredrik Lundh and Contributors.

.. image:: https://travis-ci.org/python-imaging/Pillow.png
   :target: https://travis-ci.org/python-imaging/Pillow

.. image:: https://pypip.in/v/Pillow/badge.png
    :target: https://pypi.python.org/pypi/Pillow/
    :alt: Latest PyPI version

.. image:: https://pypip.in/d/Pillow/badge.png
    :target: https://pypi.python.org/pypi/Pillow/
    :alt: Number of PyPI downloads

The documentation is hosted at http://pillow.readthedocs.org/. It contains installation instructions, tutorials, reference, compatibility details, and more.
